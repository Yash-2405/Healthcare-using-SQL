/*PROBLEM STATEMENT 4 BY YASH V*/
SELECT
    medicineID,
    SUM(productType) AS total_units,
    SUM(productType * maxPrice) AS total_max_retail_price,
    SUM(productType * maxPrice * (1 - governmentDiscount / 100)) AS total_price_after_discount
FROM
    medicine
GROUP BY
    medicineID;
