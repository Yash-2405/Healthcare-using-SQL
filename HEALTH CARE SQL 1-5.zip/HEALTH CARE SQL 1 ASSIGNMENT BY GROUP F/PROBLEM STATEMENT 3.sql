/*PROBLEM STATEMENT 3 BY REPUDI SAMUEL HONEY*/
WITH TreatmentCounts AS (
  SELECT
    per.gender,
    COUNT(DISTINCT t.treatmentid) AS total_treatments
  FROM treatment AS t
  JOIN patient AS p ON t.patientID = p.patientID
  JOIN person AS per ON p.patientID = per.personID
  GROUP BY per.gender
),
ClaimCounts AS (
  SELECT
    per.gender,
    COUNT(DISTINCT c.claimid) AS total_claims
  FROM treatment AS t
  JOIN patient AS p ON t.patientID = p.patientID
  JOIN claim AS c ON t.claimID = c.claimID
  JOIN person AS per ON p.patientID = per.personID
  GROUP BY per.gender
)
SELECT
  tc.gender,
  tc.total_treatments,
  cc.total_claims,
  tc.total_treatments / cc.total_claims AS treatment_to_claim_ratio
FROM TreatmentCounts AS tc
JOIN ClaimCounts AS cc ON tc.gender = cc.gender
ORDER BY tc.gender;