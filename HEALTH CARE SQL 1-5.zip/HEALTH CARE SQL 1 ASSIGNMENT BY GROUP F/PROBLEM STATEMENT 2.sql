/*PROBLEM STATEMENT 2 BY VAIBHAV SIMHA*/
SELECT
    t.diseaseID ,
    SUM(CASE WHEN pr.gender = 'Male' THEN 1 ELSE 0 END) AS male_count,
    SUM(CASE WHEN pr.gender = 'Female' THEN 1 ELSE 0 END) AS female_count,
    (SUM(CASE WHEN pr.gender = 'Male' THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN pr.gender = 'Female' THEN 1 ELSE 0 END), 0)) AS male_to_female_ratio
FROM Treatment t
JOIN Patient pa ON t.patientID = pa.patientID
JOIN Person pr ON pa.patientID = pr.personID
GROUP BY t.diseaseID
ORDER BY male_to_female_ratio DESC;