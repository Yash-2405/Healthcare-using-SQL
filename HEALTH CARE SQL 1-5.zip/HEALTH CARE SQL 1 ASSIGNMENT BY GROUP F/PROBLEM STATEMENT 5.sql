/*PROBLEM STATEMENT 5 BY YASH V*/
SELECT 
    p.pharmacyName,
    MAX(pr.quantity) AS max_medicines,
    MIN(pr.quantity) AS min_medicines,
    AVG(pr.quantity) AS avg_medicines
FROM 
    keep pr
JOIN 
    pharmacy p ON pr.pharmacyID = p.pharmacyID
GROUP BY 
    p.pharmacyName