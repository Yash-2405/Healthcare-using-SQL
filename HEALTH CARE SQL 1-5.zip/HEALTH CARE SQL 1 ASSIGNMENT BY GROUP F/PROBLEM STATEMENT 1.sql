/*PROBLEM STATEMENT 1 BY YASH V*/
SELECT
    CASE
        WHEN TIMESTAMPDIFF(YEAR, p.dob, CURDATE()) BETWEEN 0 AND 14 THEN 'Children'
        WHEN TIMESTAMPDIFF(YEAR, p.dob, CURDATE()) BETWEEN 15 AND 24 THEN 'Youth'
        WHEN TIMESTAMPDIFF(YEAR, p.dob, CURDATE()) BETWEEN 25 AND 64 THEN 'Adults'
        WHEN TIMESTAMPDIFF(YEAR, p.dob, CURDATE()) >= 65 THEN 'Seniors'
    END AS age_category,
    COUNT(t.treatmentID) AS treatment_count
FROM Patient p
JOIN Treatment t ON p.patientID = t.patientID
WHERE YEAR(t.date) = 2022
GROUP BY age_category; 
